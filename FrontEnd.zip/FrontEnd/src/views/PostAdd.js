
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import validator from "validator";
import axios from "axios";
import Swal from 'sweetalert2';
import url from '../api/Url'
import { blankAlert, serverDownAlert, showLoading } from "../api/Alert";
import Header from '../layout/Header.js'
import "./commonCSS.css"




export default function PostAdd() {

  let navigate = useNavigate();

  useEffect(() => {

    if (sessionStorage.getItem("userdata") == null) {
      navigate("/login");
    }
  }, [])



  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [desc, setDesc] = useState("");
  const [weight, setWeight] = useState("");
  const [rname, setRname] = useState("");
  const [rphone, setRphone] = useState("");
  const [pincode, setPincode] = useState("");


  const user = JSON.parse(sessionStorage.getItem("userdata"));


  const [data, setData] = useState({
    from_location: "",
    to_location: "",
    item_description: "",
    approx_weight: "",
    receiver_name: "",
    receiver_phone: "",
    dest_pincode: "",
    expected_deliveryDate: "",
    isBidFinalized: false,
    user: user
  })

  function changehandler(e) {
    let namee = e.target.name;
    let val = e.target.value;
    setData({ ...data, [namee]: val });
    // console.log(data.expected_deliveryDate);
  }


  const [fromErr, setfromErr] = useState(false)

  function clearError() {
    setfromErr(false)
  }

  function validate(e) {
    e.preventDefault();
    clearError();
    if (data.from_location.trim() === "" ||
      data.to_location.trim() === "" ||
      data.item_description.trim() === "" ||
      data.approx_weight.trim() === "" ||
      data.receiver_name.trim() === "" ||
      data.receiver_phone.trim() === "" ||
      data.dest_pincode.trim() === "" ||
      data.expected_deliveryDate === ""
    ) {
      Swal.fire("All fields are  required");
    } else if (
      data.from_location.length < 20 ||
      data.from_location.length > 50
    ) {
      setfromErr(true);
    }


    else {
      postAdd();
    }
  }


  function postAdd() {

    showLoading();

    if (data.from_location.trim() === "" || data.to_location.trim() === "" || data.item_description.trim() === "" || data.approx_weight == "" || data.receiver_name.trim() === "" || data.receiver_phone == "" || data.dest_pincode == "" || data.expected_deliveryDate == "") {
      blankAlert();
    }
    else {

      // console.log(data.user)


      axios.post(`${url}/advertisement`, data).then((response) => {
        Swal.showLoading();
        if (response.data.status) {

          Swal.fire(
            response.data.msg,
            'It will be visible to all the Trasporters within few seconds ! ',
            'success'
          )
          navigate('/customerhome');


        }
        else {
          Swal.fire(
            "Something Went wrong",
            'Please try again !  ',
            'error'
          )
        }

      }, (error) => serverDownAlert())

    }






  }






  return (
    <>

      <Header />
      <div className="postaddbg">
        <div className="" style={{ height: "70px" }}> </div>
        {/* <section className="vh-100" > */}
        <div className="">
          <div className="container h-100 ">
            <div className="row d-flex justify-content-center align-items-center h-100 ">
              <div className="col-lg-8 col-xl-9 ">
                <div
                  className="card text-black "
                // style={{
                //   background: "#bbf0f5d0",
                //   borderRadius: "25px",
                //   opacity: "0.8",
                // }}
                >
                  <div className="card-body p-md-5 postaddform">
                    <div className="row justify-content-center">
                      <div className="col-md-10 col-lg-6 col-xl-7 order-2 order-lg-1">
                        <p className="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">
                          Post Your Advertise Here!
                        </p>

                        <form className="mx-1 mx-md-4">
                          <div className="d-flex flex-row align-items-center mb-4">
                            <i className="fa fa-map-marker fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="text"
                                id="fname"
                                name="from_location"
                                className="form-control"
                                placeholder="From_Location"
                                onChange={changehandler}
                                onFocus={clearError}
                                value={data.from_location}
                              />
                              {fromErr ? (
                                <span className="text-danger">
                                  *Address should be 20-50 characters in length
                                </span>
                              ) : (
                                ""
                              )}
                            </div>
                          </div>

                          <div className="d-flex flex-row align-items-center mb-4">
                            <i className="fa fa-map-marker fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="text"
                                id=""
                                name="to_location"
                                className="form-control"
                                placeholder="To_Location"
                                onChange={changehandler}
                                value={data.to_location}
                              />
                            </div>
                          </div>

                          <div className="d-flex flex-row align-items-center mb-4">
                            <i class="fa fa-edit fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="text"
                                id=""
                                name="item_description"
                                className="form-control"
                                placeholder="Item_Description"
                                onChange={changehandler}
                                value={data.item_description}
                              />
                            </div>
                          </div>

                          <div className="d-flex flex-row align-items-center mb-4">
                            <i className="fa fa-balance-scale fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="number"
                                id=""
                                name="approx_weight"
                                className="form-control"
                                placeholder="Approx_weight"
                                onChange={changehandler}
                                value={data.approx_weight}
                              />
                            </div>
                          </div>

                          <div className="d-flex flex-row align-items-center mb-4">
                            <i className="fa fa-user fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="text"
                                id=""
                                name="receiver_name"
                                className="form-control"
                                placeholder="Reciever Name"
                                onChange={changehandler}
                                value={data.receiver_name}
                              />
                            </div>
                          </div>

                          <div className="d-flex flex-row align-items-center mb-4">
                            <i class="fa fa-mobile fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="number"
                                id="number"
                                name="receiver_phone"
                                className="form-control"
                                placeholder="Receiver Number"
                                onChange={changehandler}
                                value={data.receiver_phone}
                              />
                            </div>
                          </div>

                          <div className="d-flex flex-row align-items-center mb-4">
                            <i class="fa fa-map-pin fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="number"
                                id="number"
                                name="dest_pincode"
                                className="form-control"
                                placeholder="Destination Pincode"
                                onChange={changehandler}
                                value={data.dest_pincode}
                              />
                            </div>
                          </div>

                          <div className="d-flex flex-row align-items-center mb-4">
                            <i class="fa fa-calendar fa-lg me-3 fa-fw"></i>
                            <div className="form-outline flex-fill mb-0">
                              <input
                                type="date"
                                id="number"
                                name="expected_deliveryDate"
                                className="form-control"
                                placeholder="Expected Delivery Date"
                                onChange={changehandler}
                                value={data.expected_deliveryDate}
                              />
                            </div>
                          </div>

                          <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                            <button
                              type="submit"
                              className="btn btn-primary p-3 "
                              onClick={validate}
                            >
                              Post
                            </button>
                            <button
                              type="submit"
                              className="btn btn-danger p-3 "
                              onClick={() => navigate("/customerhome")}
                            >
                              Cancel
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* </section> */}
        </div>
      </div>
    </>
  );
}
