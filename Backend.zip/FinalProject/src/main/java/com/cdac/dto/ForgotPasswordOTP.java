package com.cdac.dto;

public class ForgotPasswordOTP {

	
	private int otp;

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}
	
	
}
